import configparser as cp


class Configurator:

    def __init__(self, configuration_path):
        self.configuration = cp.ConfigParser()
        self.configuration.read(configuration_path)
        self.threshold = self.configuration["K-means"].getfloat("errorThreshold")
        self.maxIterations = self.configuration["K-means"].getint("maximumNumberOfIterations")
        self.inputPath = self.configuration.get("Dataset", "inputPath")
        self.outputPath = self.configuration.get("Dataset", "outputPath")
        self.k = self.configuration["K-means"].getint("k")


    def getThreshold(self):
        return self.threshold

    def getMaxIterations(self):
        return self.maxIterations

    def getInputPath(self):
        return self.inputPath

    def getOutputPath(self):
        return self.outputPath

    def getK(self):
        return self.k


